# Riftbound Standalone Changelog

## v0.3.0 — Cursed Child

### New Mythic power: Cursed Child
- Added **Cursed Child** as a rollable Mythic power with dedicated visuals and progression-safe save normalization.
- **Monstrous Reserves** grants 4× base/max Cursed Energy. Full Rika restores 18% max Cursed Energy per owner turn; outside Full manifestation the Cursed Child passive restores 2.5%.
- **Reversed Cursed Technique** can heal the user/allies and damages spirit/undead targets with positive energy.
- **Swordsmanship** replaces Guard for the kit and arms a one-hit parry. Projectile/beam pressure is reflected at high return output; melee attacks receive a smaller counter.

### Rika
- Added **Partial Rika** as a persistent AI auxiliary fighter with Hunt, Protect, and Hold commands.
- Added **Full Rika** as a once-per-fight 15-owner-turn manifestation with stronger physical stats, massive Cursed Energy regeneration, and Mimicry access.
- Full Rika expires completely after its 15-turn timer and cannot be resummoned for the remainder of that fight.
- **Bite** copies an opponent technique on a critical hit, or automatically if Bite kills the target. Newly copied techniques operate at 70% output for their first two uses before stabilizing.
- Added Rika ultimate **Pure Love**, a high-output beam usable only during Full Rika. Firing it returns Rika to Partial manifestation.

### Mimicry
- Mimicry starts with **Thin Ice Breaker**, **Cursed Speech**, **Dhruv's Shikigami**, and a weakened **Shrine · Cleave**.
- Mimicry has no universal cooldown; each copied technique tracks its own 3-owner-turn cooldown.
- **Thin Ice Breaker** creates a solid, destructible sky-surface on the tactical map. Breaking your own Thin Ice with an attack detonates devastating spatial damage around it.
- **Cursed Speech** freezes every other combatant within 18m for one turn.
- **Dhruv's Shikigami** homes into targets and bypasses Infinity/defense barriers.

### Domain Expansion — Authentic Mutual Love
- Added a 10-owner-turn barrier domain with a preselected Mimicry technique as its recurring sure-hit.
- The sure-hit resolves each owner turn without an accuracy check while targets remain inside the barrier.
- Every domain pulse replaces the user's weapon with a randomized **Domain Katana** carrying a non-ultimate offensive technique from the game. Successful katana attacks release the embedded technique at tuned output.
- Added dedicated arena world-state presentation, falling-katana ambience, barrier styling, and minimap rendering.

### Visual presentation
- Added dedicated Cursed Child and Rika power VFX palettes/signatures.
- Added a bespoke **Pure Love** ultimate cutscene treatment.
- Added a bespoke **Authentic Mutual Love** domain-expansion cutscene and persistent domain world state.
- Added dedicated tactical-map/minimap visuals for Authentic Mutual Love and Thin Ice surfaces.

### Validation
- Existing v0.2 regression suite remains 14/14 passing.
- New Cursed Child regression suite passes 32/32 checks.
- Production bundle passes syntax/module verification.
- Real Chromium React smoke test boots Riftbound, renders the home screen, enters the Race wheel, and reports zero application errors.

## v0.2.0 — Progression, Stand fixes, UI hardening, Calamity rebalance

### Stands
- Hardened the Stand User wheel completion path so the final dungeon build resolves the actual linked Stand value instead of depending on the generic power wrapper.
- Confirmed and regression-locked exact Stand selection in the Debug Console Build Matrix.
- Hardened movement collision so a fighter's own Stand can never be treated as an occupied collider in their movement path.

### Progression
- Stat XP now converts to stat levels automatically when the threshold is reached.
- Natural per-action and movement Stat XP was reduced so passive growth stays gradual.
- Floor-clear Stat XP was retuned for slow across-the-board growth.
- Added run-level Player Level, Player XP, and Skill Points.
- Leveling grants one Skill Point per level.
- Skill Points can be invested into any uncapped stat for one immediate permanent stat level.
- Existing saves are normalized with the new progression fields on load.
- Trial full-stat-XP rewards now resolve automatically instead of requiring a manual claim.

### Stat menu / UI
- Replaced the old manual XP level-up button with `INVEST 1 SKILL POINT`.
- Added Player Level, Skill Points, and Player XP readouts to the Stat Menu.
- Increased Stat Menu bottom padding and constrained scrolling so the final row/buttons remain reachable.
- Increased cooldown-card top clearance and card height, including Stand action cards, to prevent cooldown badges/descriptions from colliding.

### Calamity balance
Mechanics were preserved; raw stat, HP, resource, and selected damage pressure were reduced.

- Generic Calamity tactical rank: 14 → 12.
- Wamuu: lower HP/resource multipliers.
- Enel: slightly lower baseline tier pressure, HP, and Energy while retaining the speed advantage mechanic.
- Anti-Spiral: reduced HP recurrence scaling.
- DIO: reduced HP and Energy multipliers while retaining his resurrection/Stand mechanics.
- Simon: reduced HP and Energy scaling while retaining Spiral evolution.
- Sukuna: substantially reduced baseline tier floor, HP, and Energy multipliers.
- Mahoraga: substantially reduced HP/resource multipliers and toned down Counter/Ultimate coefficients.
- Sukuna's basic strike and Dismantle coefficients were reduced.
- All For One: reduced minimum stat floor, HP multiplier, and Energy multiplier while retaining the factor archive.

### Validation
- `node --check` passes for the patched game bundle.
- Recovered module graph verification passes.
- v0.2 regression suite passes 14/14 checks.
- Local HTTP asset smoke test passes.
