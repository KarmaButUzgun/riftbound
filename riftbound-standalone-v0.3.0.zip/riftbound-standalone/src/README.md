# Clean-source extraction area

The standalone build currently runs the recovered production bundle in `assets/`.

Future edits should gradually move maintainable systems here instead of repeatedly hand-editing the minified bundle. A practical extraction order is:

1. Content registries: powers, Stands, races, traits, weapons.
2. Stat/progression constants and helpers.
3. Combat calculations and status effects.
4. Dungeon/boss generation.
5. Debug tools.
6. React UI components.

Until a system is extracted, `assets/page-F6OuavDb.js` remains the executable reference implementation.
