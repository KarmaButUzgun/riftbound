# Riftbound Standalone — Recovered Build v0.3.0

This is a standalone bootable copy of the recovered Riftbound web game. It uses the production game bundle and stylesheet recovered from the original website, but does **not** require the original Vinext page/router shell.

## Run it

You need Node.js installed.

### Windows
Double-click `start.bat`, then open:

`http://127.0.0.1:4173/`

### macOS / Linux
Run:

```bash
./start.sh
```

or:

```bash
npm start
```

Then open `http://127.0.0.1:4173/`.

Do not open `index.html` directly with `file://`; ES modules are intended to be served over HTTP.

## Verify the recovered module graph

```bash
npm run verify
```

Run the complete gameplay-regression suite with:

```bash
npm run regression
```


## v0.3.0 — Cursed Child

This build adds the Mythic **Cursed Child** power as a full combat system: Rika AI/commands, Partial and Full manifestation, Mimicry and copied-technique inventory, Swordsmanship parries, RCE, Bite-based technique copying, Pure Love, and the 10-turn **Authentic Mutual Love** domain with rotating sure-hit techniques and randomized technique katanas. Dedicated arena, minimap, Thin Ice, power-VFX, and ultimate/domain presentation are included.

## What is recovered

- `assets/page-F6OuavDb.js` — Riftbound game/page component and gameplay data/logic.
- `assets/riftbound.css` — full recovered Riftbound stylesheet.
- `assets/framework-CXnKph_e.js` — recovered React/ReactDOM runtime.
- `assets/rolldown-runtime-S-ySWqyJ.js` — required bundler helper.
- `assets/index-CzvACZaC.js` and `assets/layout-segment-context-CP-Sz4wR.js` — preserved framework assets, currently not required by the standalone launcher.
- `recovered-original/` — untouched copies of the files supplied during recovery.

## How the standalone launcher works

The recovered framework bundle was tree-shaken to expose `hydrateRoot` rather than `createRoot`. The launcher therefore includes the exact first-render loading markup (`OPENING THE RIFT`) in `index.html`, then hydrates it with the recovered Riftbound component. Riftbound transitions to the normal home screen after its local-save initialization effect runs.

## Current validation

The recovered build was smoke-tested in Chromium by loading the JS/CSS modules into an isolated browser document. It successfully:

- hydrated with React 19.2.6;
- transitioned from `OPENING THE RIFT` to the Riftbound home screen;
- rendered the recovered game UI and content;
- opened the Race wheel after pressing `FORGE A NEW RUN`;
- produced no application exceptions during that path.

Riftbound's production page bundle contains no direct `fetch`, XHR, WebSocket, EventSource, or service-worker calls, which is consistent with the recovered game being able to operate as a client-side/local-save app.

## Next development step

The game is running from a compiled production bundle. The `src/` folder is the clean-source extraction area. Move systems there gradually before making large long-term additions, so new powers, bosses, progression changes, and UI fixes stop depending on direct edits to the minified bundle.


## v0.2 gameplay changes

This build contains the first direct gameplay patch on top of the recovered client: Stand User entry hardening, exact Stand debug selection regression coverage, own-Stand collision hardening, cooldown-card spacing fixes, automatic Stat XP growth, Player Level/XP/Skill Points, Stat Menu scrolling fixes, and a substantial raw-stat/HP/resource rebalance for Calamity bosses. See `CHANGELOG.md` for exact changes.
