#!/usr/bin/env sh
cd "$(dirname "$0")"
exec node serve.mjs
