from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
JS = ROOT / 'assets/page-F6OuavDb.js'
CSS = ROOT / 'assets/riftbound.css'

s = JS.read_text()
css = CSS.read_text()

changes = []

def repl(old, new, label, count=1):
    global s
    actual = s.count(old)
    if actual != count:
        raise SystemExit(f'{label}: expected {count} occurrence(s), found {actual}')
    s = s.replace(old, new, count)
    changes.append(label)

def repl_css(old, new, label, count=1):
    global css
    actual = css.count(old)
    if actual != count:
        raise SystemExit(f'{label}: expected {count} occurrence(s), found {actual}')
    css = css.replace(old, new, count)
    changes.append(label)

# ---------------------------------------------------------------------------
# Progression: automatic stat growth + player level / skill points.
# ---------------------------------------------------------------------------
old = 'function Be(e){let t=M(e,0,19);return Math.round(58+t*27+(t+1)**1.45*8)}'
new = '''function Be(e){let t=M(e,0,19);return Math.round(58+t*27+(t+1)**1.45*8)}function RIFT_LEVEL_NEED(e){let t=Math.max(1,Math.round(e||1));return Math.round(105+(t-1)*58+(t-1)**1.32*14)}function RIFT_NORMALIZE_LEVEL(e){e.playerLevel=Math.max(1,Math.round(e.playerLevel||1)),e.playerXp=Math.max(0,Math.round(e.playerXp||0)),e.skillPoints=Math.max(0,Math.round(e.skillPoints||0));let t=RIFT_LEVEL_NEED(e.playerLevel);for(;e.playerXp>=t&&e.playerLevel<999;)e.playerXp-=t,e.playerLevel+=1,e.skillPoints+=1,t=RIFT_LEVEL_NEED(e.playerLevel);return e}function RIFT_GAIN_PLAYER_XP(e,t){RIFT_NORMALIZE_LEVEL(e);let n=e.playerLevel;return e.playerXp+=Math.max(0,Math.round(t||0)),RIFT_NORMALIZE_LEVEL(e),e.playerLevel-n}function RIFT_SPEND_SKILL_POINT(e,t){if(RIFT_NORMALIZE_LEVEL(e),!D.includes(t)||e.skillPoints<=0)return!1;let n=e.player;if(Wr(n),n.tiers[t]>=Kr(n,t))return!1;let r=Be(n.tiers[t]),i=Math.max(0,r-(n.statXp?.[t]||0));return n.statXp[t]+=i,e.skillPoints-=1,Jr(n,t)}'''
repl(old, new, 'add player-level and skill-point helpers')

old = 'function qr(e,t){Wr(e);let n={};return D.forEach(r=>{if(e.tiers[r]>=Kr(e,r))return;let i=Math.max(0,Math.round(t[r]||0));i&&(e.statXp[r]+=i,n[r]=i)}),n}'
new = 'function qr(e,t){Wr(e);let n={};return D.forEach(r=>{if(e.tiers[r]>=Kr(e,r))return;let i=Math.max(0,Math.round(t[r]||0));if(i){e.statXp[r]+=i,n[r]=i;for(let t=0;t<6&&Jr(e,r);t++);}}),n}'
repl(old, new, 'make stat XP auto-level stats')

old = 'function Yr(e,t){let n=t.move?.tags||[],r=t.type===`ultimate`?18:t.type===`special`?11:7,i={},a=(e,t)=>{i[e]=(i[e]||0)+t};(t.type===`strike`||t.type===`weapon`)&&(a(`ap`,r),a(`combatSkill`,r)),t.type===`guard`&&(a(`durability`,r+2),a(`battleIq`,r)),t.type===`rest`&&(a(`energy`,r+3),a(`regeneration`,r+2)),(t.type===`special`||t.type===`ultimate`)&&(a(`ap`,r),a(`energy`,Math.ceil(r*.8)),a(`battleIq`,Math.ceil(r*.55)),Tt(t,e.player).requiresAim&&(a(`range`,Math.ceil(r*.75)),a(`combatSkill`,Math.ceil(r*.45))),n.some(e=>[`spatial`,`causal`,`reality`,`hakiKen`].includes(e))&&a(`iq`,Math.ceil(r*.65))),qr(e.player,i)}'
new = 'function Yr(e,t){let n=t.move?.tags||[],r=t.type===`ultimate`?7:t.type===`special`?4:2,i={},a=(e,t)=>{i[e]=(i[e]||0)+t};(t.type===`strike`||t.type===`weapon`)&&(a(`ap`,r),a(`combatSkill`,r)),t.type===`guard`&&(a(`durability`,r+1),a(`battleIq`,r)),t.type===`rest`&&(a(`energy`,r+1),a(`regeneration`,r+1)),(t.type===`special`||t.type===`ultimate`)&&(a(`ap`,r),a(`energy`,Math.ceil(r*.65)),a(`battleIq`,Math.ceil(r*.45)),Tt(t,e.player).requiresAim&&(a(`range`,Math.ceil(r*.55)),a(`combatSkill`,Math.ceil(r*.4))),n.some(e=>[`spatial`,`causal`,`reality`,`hakiKen`].includes(e))&&a(`iq`,Math.ceil(r*.5))),qr(e.player,i)}'
repl(old, new, 'slow natural per-action stat XP')

old = 'qr(t.player,{speed:Math.max(2,Math.ceil(n.traveledDistance*1.25)),battleIq:Math.max(1,Math.ceil(n.spentCost*.28))})'
new = 'qr(t.player,{speed:Math.max(1,Math.ceil(n.traveledDistance*.22)),battleIq:Math.max(1,Math.ceil(n.spentCost*.08))})'
repl(old, new, 'slow movement-derived stat XP')

old = 'function _s(e){let t=10+Math.min(24,Math.floor(e.floor*1.25)),n=e.boss?1.65:e.elite?1.3:1,r=Object.fromEntries(D.map((r,i)=>[r,Math.round(t*n*(.62+(e.floor+i*3)%5*.055))]));qr(e.player,r);let i=D.filter(t=>e.player.tiers[t]<Kr(e.player,t)&&(e.player.statXp?.[t]||0)>=Be(e.player.tiers[t])).length;G(e,`STAT XP // Floor ${e.floor} combat experience settles across all nine disciplines${i?` · ${i} upgrade${i===1?``:`s`} ready in the Stat Menu`:``}.`,i?`limit`:`player`)}'
new = 'function _s(e){let t=5+Math.min(11,Math.floor(e.floor*.45)),n=e.boss?1.45:e.elite?1.2:1,r=Object.fromEntries(D.map((r,i)=>[r,Math.round(t*n*(.58+(e.floor+i*3)%5*.045))])),i=RIFT_GAIN_PLAYER_XP(e,Math.round(58+e.floor*5+(e.boss?70:0)+(e.elite?28:0)));qr(e.player,r),G(e,`PROGRESSION // Floor ${e.floor} experience settles naturally across all nine disciplines. Player Level ${e.playerLevel} · ${e.playerXp}/${RIFT_LEVEL_NEED(e.playerLevel)} XP${i?` · LEVEL UP${i>1?` x${i}`:``} · +${i} SKILL POINT${i===1?``:`S`}`:``}.`,i?`limit`:`player`)}'
repl(old, new, 'add global XP and slow floor-clear stat XP')

old = 'G(e,`OATH FULFILLED // The dungeon grants a full level\'s worth of ${c[t]} XP. Claim it in the Stat Menu.`,`limit`)'
new = 'G(e,`OATH FULFILLED // The dungeon grants a full level\'s worth of ${c[t]} XP. Natural progression applies it immediately.`,`limit`)'
repl(old, new, 'update trial reward copy for auto-leveling')

old = 'floor:1,wins:0,turn:1,player:e,enemy:r,boss:!1'
new = 'floor:1,wins:0,turn:1,playerLevel:1,playerXp:0,skillPoints:0,player:e,enemy:r,boss:!1'
repl(old, new, 'initialize player level progression on new runs')

old = 'function Oa(e){let t=e=>{if(e.power.name!==`Speedster`)return;'
new = 'function Oa(e){RIFT_NORMALIZE_LEVEL(e);let t=e=>{if(e.power.name!==`Speedster`)return;'
repl(old, new, 'normalize progression on loaded saves')

# Harden Stand User wheel completion by resolving the actual linked Stand value.
old = 'let n={...e.pendingAffinities},r=Le(n),i=ke.trait.value,{fighter:a,stand:o}=Ur(`Wayfarer`,ke.race.value,i,ke.power.name,String(ke.weaponType.value),ke.weapon.value,r),s=Da(a,n);'
new = 'let n={...e.pendingAffinities},r=Le(n),i=ke.trait.value,standPick=i.name===`Stand User`?(ke.power?.value?.name||ke.power?.name||h[0].name):ke.power.name,{fighter:a,stand:o}=Ur(`Wayfarer`,ke.race.value,i,standPick,String(ke.weaponType.value),ke.weapon.value,r),s=Da(a,n);'
repl(old, new, 'harden Stand User dungeon-entry build resolution')

# Repurpose the old manual XP ascension handler into explicit skill-point investment.
old = 'ho=e=>{if(!w)return;let t=w.phase===`combat`&&In(w.player);if(!t&&![`intermission`,`hakiTraining`].includes(w.phase))return;let n=P(w),r=n.player.tiers[e];if(!Jr(n.player,e))return;let i=Fe(n.affinities,e);G(n,`${t?`SPIRAL SKILL TREE`:`STAT ASCENSION`} // ${c[e]} rises from ${Br(e,r)} to ${Br(e,n.player.tiers[e])}. ${i?`Affinity granted +${i} starting level${i===1?``:`s`}; `:``}cap ${Br(e,Kr(n.player,e))}.`,`limit`),T(n),q(`limit`)}'
new = 'ho=e=>{if(!w)return;let t=P(w),n=t.player.tiers[e];if(!RIFT_SPEND_SKILL_POINT(t,e))return;let r=Fe(t.affinities,e);G(t,`SKILL POINT INVESTED // ${c[e]} rises from ${Br(e,n)} to ${Br(e,t.player.tiers[e])}. ${t.skillPoints} skill point${t.skillPoints===1?``:`s`} remain. ${r?`Affinity contributes +${r} starting level${r===1?``:`s`}; `:``}cap ${Br(e,Kr(t.player,e))}.`,`limit`),T(t),q(`limit`)}'
repl(old, new, 'convert stat menu action to skill-point investment')

old = 'children:`Combat, movement, intel, floor clears, training items, and Spiral Evolution bank Stat XP. XP only becomes a level here, and affinity caps can never be bypassed.`'
new = 'children:`Stats train themselves slowly through use. Stat XP automatically converts into permanent levels when a threshold is reached. Player Level earns Skill Points, which can be invested into any uncapped stat for an immediate level.`'
repl(old, new, 'rewrite stat-menu progression explanation')

old = 'children:[je.reduce((e,t)=>e+w.affinities[t],0),(0,E.jsx)(`small`,{children:`AFFINITY RANKS`})]}),(0,E.jsxs)(`b`,{children:[D.filter(e=>w.player.tiers[e]>=Kr(w.player,e)).length,(0,E.jsx)(`small`,{children:`CAPS REACHED`})]})'
new = 'children:[w.playerLevel||1,(0,E.jsx)(`small`,{children:`PLAYER LEVEL`})]}),(0,E.jsxs)(`b`,{children:[w.skillPoints||0,(0,E.jsx)(`small`,{children:`SKILL POINTS`})]}),(0,E.jsxs)(`b`,{children:[`${w.playerXp||0}/${RIFT_LEVEL_NEED(w.playerLevel||1)}`,(0,E.jsx)(`small`,{children:`PLAYER XP`})]}),(0,E.jsxs)(`b`,{children:[D.filter(e=>w.player.tiers[e]>=Kr(w.player,e)).length,(0,E.jsx)(`small`,{children:`CAPS REACHED`})]})'
repl(old, new, 'show player level / XP / skill points in stat menu')

old = 'a=t>=n,o=[`intermission`,`hakiTraining`].includes(w.phase)||w.phase===`combat`&&In(w.player),s=Ne.filter'
new = 'a=t>=n,o=(w.skillPoints||0)>0,s=Ne.filter'
repl(old, new, 'drive stat-card readiness from skill points')

old = 'className:`${a?`capped`:``} ${r>=i&&!a?`ready`:``}`'
new = 'className:`${a?`capped`:``} ${o&&!a?`ready`:``}`'
repl(old, new, 'highlight stats when a skill point is spendable')

old = 'disabled:!o||a||r<i,onClick:()=>ho(e),children:a?`AFFINITY CAP`:r>=i?`LEVEL UP · ${i} XP`:`${i-r} XP NEEDED`'
new = 'disabled:!o||a,onClick:()=>ho(e),children:a?`AFFINITY CAP`:o?`INVEST 1 SKILL POINT`:`NO SKILL POINTS`'
repl(old, new, 'replace manual XP level button with skill-point button')

old = 'children:w.phase===`combat`?`SPIRAL EXCEPTION · Skill Tree changes cost no combat action.`:`STAT MENU · Available after every cleared floor.`'
new = 'children:w.phase===`combat`?`SPIRAL EXCEPTION · Skill Point investment costs no combat action.`:`NATURAL TRAINING · Stat XP levels automatically. Spend Player Level points here.`'
repl(old, new, 'update stat-menu footer')

# ---------------------------------------------------------------------------
# Stand collision: make the own-Stand exclusion a rule in path collision too.
# ---------------------------------------------------------------------------
old = 'c=f.find(e=>I(i,e.position)<=O*2.08),d=Ot(e,m,i);'
new = 'c=f.find(e=>e.id!==Cn(n)&&I(i,e.position)<=O*2.08),d=Ot(e,m,i);'
repl(old, new, 'guarantee owner movement ignores its own Stand collider')

# ---------------------------------------------------------------------------
# Calamity boss balance pass. Keep mechanics intact, lower raw stat/HP pressure.
# ---------------------------------------------------------------------------
repl('s.statuses.tacticalRank=14', 's.statuses.tacticalRank=12', 'lower generic Calamity tactical rank')
repl('ui(e,7,t),2.05,1.65', 'ui(e,7,t),1.78,1.5', 'rebalance Wamuu durability/resources')
repl('ui(e,10,t);n.speed=M(Math.max(12,t.tiers.speed+1),0,19);let r=di(`Enel · God of the Thunderhead`,`Demigod`,`Combat Analysis`,si,n,2.2,1.8)', 'ui(e,9,t);n.speed=M(Math.max(11,t.tiers.speed+1),0,19);let r=di(`Enel · God of the Thunderhead`,`Demigod`,`Combat Analysis`,si,n,1.88,1.58)', 'rebalance Enel stats/durability/resources')
repl('s=1.35+e*.02+n*.12', 's=1.18+e*.012+n*.08', 'rebalance Anti-Spiral HP recurrence scaling')
repl('r.maxHp=Math.round(r.maxHp*2.05)', 'r.maxHp=Math.round(r.maxHp*1.78)', 'rebalance DIO HP')
repl('r.maxEnergy=Math.round(r.maxEnergy*1.65)', 'r.maxEnergy=Math.round(r.maxEnergy*1.5)', 'rebalance DIO energy')
repl('t,2.35+Math.max(0,e-30)*.01,2.4', 't,1.92+Math.max(0,e-30)*.008,2.0', 'rebalance Simon durability/resources')
repl('ui(e,13,t),2.65,2', 'ui(e,11,t),1.92,1.62', 'rebalance Sukuna base stats/durability/resources')
repl('ui(e,12,t),1.75,1.45', 'ui(e,10,t),1.38,1.28', 'rebalance Mahoraga durability/resources')
repl('D.forEach(e=>{r[e]=Math.max(15,r[e])});let i=di(`All For One · The Vault of Every Answer`,`Human`,`Combat Analysis`,n,r,3.25,2.4)', 'D.forEach(e=>{r[e]=Math.max(13,r[e])});let i=di(`All For One · The Vault of Every Answer`,`Human`,`Combat Analysis`,n,r,2.25,1.82)', 'rebalance All For One raw stats/durability/resources')

# Tone down the most oppressive Sukuna/Mahoraga raw move coefficients while preserving mechanics.
repl('cost:16,power:1.34,destruction:1.65,tags:[`physical`,`heavy`,`calamitySukunaStrike`]', 'cost:16,power:1.2,destruction:1.5,tags:[`physical`,`heavy`,`calamitySukunaStrike`]', 'rebalance Sukuna basic strike')
repl('cost:28,power:1.82,destruction:3.9,tags:[`magic`,`shrineTechnique`,`shrineSlash`,`accurate`]', 'cost:28,power:1.58,destruction:3.35,tags:[`magic`,`shrineTechnique`,`shrineSlash`,`accurate`]', 'rebalance Sukuna Dismantle')
repl('cost:30,power:1.95,destruction:2.75,tags:[`physical`,`guardbreak`,`mahoragaCounter`]', 'cost:30,power:1.68,destruction:2.45,tags:[`physical`,`guardbreak`,`mahoragaCounter`]', 'rebalance Mahoraga counter')
repl('cost:100,power:3.2,destruction:4.5,tags:[`physical`,`guardbreak`,`noCounter`,`allEnergy`]', 'cost:100,power:2.72,destruction:4.1,tags:[`physical`,`guardbreak`,`noCounter`,`allEnergy`]', 'rebalance Mahoraga ultimate')

# ---------------------------------------------------------------------------
# CSS: cooldown overlap hardening + stat-menu scroll safety + progression chips.
# ---------------------------------------------------------------------------
repl_css('.action-card:has(.action-card-meta){min-height:96px;padding-top:34px}', '.action-card:has(.action-card-meta){min-height:108px;padding-top:40px}.action-card:has(.action-card-meta) .action-copy small{white-space:normal;line-height:1.25;max-height:2.5em;overflow:hidden}', 'harden action-card cooldown spacing')
repl_css('.stand-action-grid>button:has(.move-cooldown-badge){min-height:132px;padding-top:37px}', '.stand-action-grid>button:has(.move-cooldown-badge){min-height:142px;padding-top:42px}', 'harden Stand cooldown spacing')
repl_css('.stat-menu-content,.contracts-content{max-height:92vh;padding:30px 34px 36px;overflow-y:auto}', '.stat-menu-content,.contracts-content{max-height:min(88vh,900px);padding:30px 34px 84px;overflow-y:auto;overscroll-behavior:contain;scrollbar-gutter:stable}.stats-modal{max-height:94vh;overflow:hidden}', 'fix stat menu scroll bottom and upgrade visibility')

JS.write_text(s)
CSS.write_text(css)

print(f'Applied {len(changes)} patch operations:')
for c in changes:
    print(' -', c)
