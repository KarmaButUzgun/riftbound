import { readFile } from "node:fs/promises";
import { createHash } from "node:crypto";

const files = [
  "assets/page-F6OuavDb.js",
  "assets/framework-CXnKph_e.js",
  "assets/rolldown-runtime-S-ySWqyJ.js",
  "assets/riftbound.css",
];

for (const file of files) {
  const data = await readFile(new URL(`../${file}`, import.meta.url));
  const hash = createHash("sha256").update(data).digest("hex").slice(0, 16);
  console.log(`${file}: ${data.length} bytes  sha256:${hash}`);
}

const app = await import(new URL("../assets/page-F6OuavDb.js", import.meta.url));
const framework = await import(new URL("../assets/framework-CXnKph_e.js", import.meta.url));
const pageText = await readFile(new URL("../assets/page-F6OuavDb.js", import.meta.url), "utf8");

if (typeof app.default !== "function") throw new Error("Riftbound default component was not recovered.");
if (framework.i().version !== "19.2.6") throw new Error("Unexpected recovered React version.");
if (typeof framework.t().hydrateRoot !== "function") throw new Error("Recovered hydrateRoot runtime is missing.");

const networkPrimitives = ["fetch(", "XMLHttpRequest", "WebSocket", "EventSource", "navigator.serviceWorker"];
const found = networkPrimitives.filter((token) => pageText.includes(token));
console.log(`Riftbound component: ${app.default.name || "anonymous"}`);
console.log(`Recovered React: ${framework.i().version}`);
console.log(`Direct app network primitives: ${found.length ? found.join(", ") : "none found"}`);
console.log("VERIFY OK");
