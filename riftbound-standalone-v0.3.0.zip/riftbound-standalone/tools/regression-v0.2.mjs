import fs from 'node:fs';

const js = fs.readFileSync(new URL('../assets/page-F6OuavDb.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../assets/riftbound.css', import.meta.url), 'utf8');

const checks = [
  ['Stand User wheel completion resolves linked Stand', js.includes('standPick=i.name===`Stand User`?(ke.power?.value?.name||ke.power?.name||h[0].name):ke.power.name')],
  ['Debug exact Stand selector exists', js.includes('children:`Stand`}),(0,E.jsx)(`select`,{value:Gr,onChange:e=>Qr(e.target.value),children:h.map')],
  ['Debug forge uses exact selected Stand', js.includes('t.name===`Stand User`?r.name:n.name')],
  ['Own Stand excluded from occupied movement list', js.includes('e.id!==Cn(n)&&I(i,e.position)<=O*2.08')],
  ['Player level normalization exists', js.includes('function RIFT_NORMALIZE_LEVEL')],
  ['Skill point investment exists', js.includes('function RIFT_SPEND_SKILL_POINT')],
  ['Natural stat XP auto-levels', js.includes('for(let t=0;t<6&&Jr(e,r);t++)')],
  ['Stat menu exposes player level', js.includes('children:`PLAYER LEVEL`')],
  ['Stat menu exposes skill points', js.includes('children:`SKILL POINTS`')],
  ['Cooldown cards have extra top clearance', css.includes('.action-card:has(.action-card-meta){min-height:108px;padding-top:40px}')],
  ['Stat menu scroll has bottom safety padding', css.includes('padding:30px 34px 84px;overflow-y:auto')],
  ['Sukuna HP multiplier reduced', js.includes('ui(e,11,t),1.92,1.62')],
  ['Mahoraga HP multiplier reduced', js.includes('ui(e,10,t),1.38,1.28')],
  ['All For One raw floor reduced', js.includes('Math.max(13,r[e])')],
];

let failed = 0;
for (const [name, ok] of checks) {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}`);
  if (!ok) failed += 1;
}
if (failed) process.exit(1);
console.log(`REGRESSION OK (${checks.length} checks)`);
