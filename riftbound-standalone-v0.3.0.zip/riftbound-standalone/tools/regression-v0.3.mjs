import fs from 'node:fs';

const js = fs.readFileSync(new URL('../assets/page-F6OuavDb.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../assets/riftbound.css', import.meta.url), 'utf8');

const checks = [
  ['Cursed Child is a Mythic rollable power', js.includes('name:`Cursed Child`,rarity:`Mythic`')],
  ['Rika companion power is unrollable', js.includes('name:`Rika Manifestation`,rarity:`Mythic`,rarityLabel:`Unrollable · Cursed Child Companion`,rollable:!1,enemyRollable:!1')],
  ['Monstrous Reserves quadruples base energy', js.includes('r.name===`Cursed Child`&&(l*=4)') && js.includes('RIFT_CURSED_CHILD(e)&&(n*=4)')],
  ['RCE has ally healing and hostile positive-energy damage', js.includes('function RIFT_RCE') && js.includes('REVERSED CURSED TECHNIQUE') && js.includes('POSITIVE ENERGY')],
  ['RCE recognizes explicit undead/spirit targets', js.includes('[`Echo Wraith`,`Vengeful Spirit`].includes(s.race?.name)')],
  ['Swordsmanship replaces Guard with a live parry', js.includes('id:`cursed-swordsmanship`') && js.includes('statuses.cursedSwordParry=1')],
  ['Swordsmanship can return projectile pressure', js.includes('SWORDSMANSHIP · RETURN') && js.includes('parryReturn')],
  ['Mimicry starts with Thin Ice, Cursed Speech, Dhruv, and Shrine', ['thin-ice-breaker','cursed-speech','dhruv-shikigami','mimic-shrine'].every(id => js.includes(`id:\`${id}\``))],
  ['Mimicry is locked behind Full Rika', js.includes('Mimicry requires Fully Manifested Rika')],
  ['Copied techniques use isolated cooldown keys', js.includes('mimicCooldown_') && js.includes('e.statuses[r]=Math.max(e.statuses[r]||0,4)')],
  ['Fresh Bite copies begin at reduced output', js.includes('FRESH COPY') && js.includes('a=i>0?.7:1')],
  ['Critical or killing Bite can copy techniques', js.includes('h.includes(`rikaBite`)&&de>0&&(C||a.hp<=0)&&RIFT_COPY_TECHNIQUE')],
  ['Partial and Full Rika are AI auxiliaries', js.includes('function RIFT_BUILD_RIKA') && js.includes('statuses.rikaCompanion=1')],
  ['Rika exposes Hunt / Protect / Hold commands', js.includes('for(let[n,r,i]of[[`hunt`,`牙`') && js.includes('`protect`,`護`') && js.includes('`hold`,`止`') && js.includes('tags:[`rikaCommand`,`rikaCommand:${n}`')],
  ['Full Rika has a 15 owner-turn timer', js.includes('statuses.rikaFullTurns=15') && js.includes('FULL MANIFESTATION EXPIRES')],
  ['Full Rika massively boosts CE regeneration', js.includes('MONSTROUS RESERVES · FULL RIKA') && js.includes('i?.18:.025')],
  ['Pure Love is queued through Rika AI', js.includes('rikaPureLoveCommand') && js.includes('rikaForcedPureLove')],
  ['Pure Love downgrades Rika to partial afterwards', js.includes('h.includes(`rikaPureLove`)&&RIFT_RIKA_FIGHTER(i)&&RIFT_DOWNGRADE_RIKA')],
  ['Authentic Mutual Love is a 10-owner-turn barrier domain', js.includes('name:`Authentic Mutual Love`,radius:26,turns:10') && js.includes('t.kind===`authenticMutualLove`')],
  ['Domain sure-hit can be preselected from Mimicry', js.includes('authenticLoveSureHitId') && js.includes('cursedCycleSureHit')],
  ['Domain applies recurring sure-hit without accuracy checks', js.includes('domainSureHit') && js.includes('AUTHENTIC MUTUAL LOVE · SURE-HIT')],
  ['Domain rolls a replacement technique katana every pulse', js.includes('function RIFT_ROLL_KATANA') && js.includes('DOMAIN KATANA')],
  ['Successful domain-katana hit releases its embedded technique', js.includes('authenticLoveKatanaProc') && js.includes('BOUND TECHNIQUE')],
  ['Thin Ice creates a breakable map surface', js.includes('kind:`thinIce`') && js.includes('THIN ICE BREAKER // A drawn sky-surface hardens')],
  ['Breaking owned Thin Ice detonates spatial damage', js.includes('r===`thinIce`&&t.ownerId===Do(e,n)?.id') && js.includes('mimicThinIceBreak')],
  ['Cursed Speech freezes everyone else in 18m', js.includes('CURSED SPEECH · STOP') && js.includes('<=18')],
  ['Dhruv shikigami bypass Infinity/barriers', js.includes('`mimicDhruv`,`multi`,`guaranteedHit`,`infinityBypass`,`ignoreDefenseHax`,`noCounter`')],
  ['Cursed Child has a dedicated ultimate cutscene signature', js.includes('"Cursed Child":L(`authentic-mutual-love`')],
  ['Rika has a dedicated Pure Love cutscene signature', js.includes('"Rika Manifestation":L(`pure-love`')],
  ['Authentic Mutual Love changes arena visuals', css.includes('.barrier-domain-ambient.domain-authenticMutualLove')],
  ['Authentic Mutual Love has dedicated minimap styling', css.includes('.map-domain.domain-authenticMutualLove')],
  ['Thin Ice has dedicated minimap styling', css.includes('.map-feature.feature-thinIce') && css.includes('.map-feature.feature-thinIce.taking-damage')],
];

let failed = 0;
for (const [name, ok] of checks) {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}`);
  if (!ok) failed += 1;
}
if (failed) process.exit(1);
console.log(`REGRESSION OK (${checks.length} checks)`);
