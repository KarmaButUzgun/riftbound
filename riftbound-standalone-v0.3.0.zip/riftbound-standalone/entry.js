import { i as reactFactory, t as reactDomClientFactory } from "./assets/framework-CXnKph_e.js";
import Riftbound from "./assets/page-F6OuavDb.js";

const React = reactFactory();
const ReactDOMClient = reactDomClientFactory();
const root = document.getElementById("root");

window.__RIFTBOUND_STANDALONE__ = {
  recovered: true,
  version: "0.3.0",
};

ReactDOMClient.hydrateRoot(root, React.createElement(Riftbound));
